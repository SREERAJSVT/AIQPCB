*PADS-LIBRARY-PART-TYPES-V9*

ENS160-BGLT ENS160BGLT I ANA 7 1 0 0 0
TIMESTAMP 2026.03.08.11.20.18
"Mouser Part Number" 135-ENS160-BGLT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ScioSense/ENS160-BGLT?qs=DRkmTr78QAQdCF%2F7WcskoA%3D%3D
"Manufacturer_Name" ScioSense
"Manufacturer_Part_Number" ENS160-BGLT
"Description" Air Quality Sensors ENS160-BGLT LGA9 T&R 1K5
"Datasheet Link" https://www.sciosense.com/wp-content/uploads/2023/12/ENS160-Datasheet.pdf
"Geometry.Height" 0.9mm
GATE 1 9 0
ENS160-BGLT
1 0 U MOSI_/_SDA
2 0 U SCLK_/_SCL
3 0 U MISO_/_ADDR
4 0 U VDD
5 0 U VDDIO
6 0 U INTN
7 0 U CSN
8 0 U VSS_1
9 0 U VSS_2

*END*
*REMARK* SamacSys ECAD Model
15529717/907534/2.50/9/3/Integrated Circuit
