*PADS-LIBRARY-PART-TYPES-V9*

SHT41-AD1B-R2 SHT41AD1BR2 I ANA 7 1 0 0 0
TIMESTAMP 2026.03.08.09.56.49
"Mouser Part Number" 403-SHT41-AD1B-R2
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Sensirion/SHT41-AD1B-R2?qs=XAiT9M5g4x92rdly9nbdGg%3D%3D
"Manufacturer_Name" Sensirion
"Manufacturer_Part_Number" SHT41-AD1B-R2
"Description" Board Mount Humidity Sensors Intermediate Humidity and Temperature Sensor
"Datasheet Link" https://sensirion.com/media/documents/33FD6951/61641E1E/Sensirion_Humidity_Sensors_SHT4x_Datasheet.pdf
"Geometry.Height" 0.59mm
GATE 1 4 0
SHT41-AD1B-R2
1 0 U SDA
2 0 U SCL
3 0 U VDD
4 0 U VSS

*END*
*REMARK* SamacSys ECAD Model
15423891/907534/2.50/4/3/Integrated Circuit
