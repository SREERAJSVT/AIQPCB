*PADS-LIBRARY-PART-TYPES-V9*

BME688 BME688 I ANA 7 1 0 0 0
TIMESTAMP 2026.03.08.09.54.34
"Mouser Part Number" 262-BME688
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bosch-Sensortec/BME688?qs=IS%252B4QmGtzzqQoVDscqwx3A%3D%3D
"Manufacturer_Name" BOSCH
"Manufacturer_Part_Number" BME688
"Description" Gas sensor measuring relative humidity, barometric pressure, ambient temperature and gas (VOC)
"Datasheet Link" https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bme688-ds000.pdf
"Geometry.Height" 1mm
GATE 1 8 0
BME688
1 0 U GND_1
2 0 U CSB
3 0 U SDI
4 0 U SCK
5 0 U SDO
6 0 U VDDIO
7 0 U GND_2
8 0 U VDD

*END*
*REMARK* SamacSys ECAD Model
13688973/907534/2.50/8/3/Integrated Circuit
