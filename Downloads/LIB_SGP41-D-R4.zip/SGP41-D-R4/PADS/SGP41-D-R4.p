*PADS-LIBRARY-PART-TYPES-V9*

SGP41-D-R4 SON80P244X244X95-7N I ANA 7 1 0 0 0
TIMESTAMP 2026.03.08.09.55.35
"Mouser Part Number" 403-SGP41-D-R4
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Sensirion/SGP41-D-R4?qs=A6eO%252BMLsxmRqwfOE5NYPVA%3D%3D
"Manufacturer_Name" Sensirion
"Manufacturer_Part_Number" SGP41-D-R4
"Description" Air Quality Sensors VOC and NOx (MOX) Gas Pollutant Sensor
"Datasheet Link" https://www.sensirion.com/fileadmin/user_upload/customers/sensirion/Dokumente/9_Gas_Sensors/Datasheets/Sensirion_Gas_Sensors_Datasheet_SGP41.pdf
"Geometry.Height" 0.95mm
GATE 1 7 0
SGP41-D-R4
1 0 U VDD
2 0 U VSS
3 0 U SDA
7 0 U EP
6 0 U SCL
5 0 U VDDH
4 0 U N/A

*END*
*REMARK* SamacSys ECAD Model
15395225/907534/2.50/7/3/Integrated Circuit
